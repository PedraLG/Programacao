import axios, { AxiosRequestConfig, AxiosResponse, AxiosError } from 'axios';
 

export class SpotifyService {
  url = 'https://spotify23.p.rapidapi.com';
  headers= {
    'x-rapidapi-key': 'e2750c9885msh64b791ccb532c0cp1bb39cjsn083649691980',
    'x-rapidapi-host': 'spotify23.p.rapidapi.com'
  }
  
  private async apiCall(config: AxiosRequestConfig): Promise<any> {
    try {
      const response: AxiosResponse = await axios(config);
      return response.data;
    } catch (error) {
      const axiosError = error as AxiosError;

      if (axiosError.response && axiosError.response.status === 429) {
        const retryAfterHeader = axiosError.response.headers['retry-after'];
        const waitTimeInSeconds = retryAfterHeader ? parseInt(retryAfterHeader) : 5;
        const waitTimeInMilliseconds = waitTimeInSeconds * 1000;

        console.warn(`Limite de pedidos atingido (429). A tentar novamente após ${waitTimeInSeconds} segundos.`);

        await new Promise(resolve => setTimeout(resolve, waitTimeInMilliseconds));

        return this.apiCall(config);
      }
      throw error;
    }
  }

  searchTracks(title: string): Promise<any> {
    const config: AxiosRequestConfig = {url: `${this.url}/search?q=${encodeURI(title)}&type="tracks"`, method: 'get', headers: this.headers};
    return this.apiCall(config).then(data => {
      return data;
    });
  }

  searchAlbums(title: string): Promise<any> {
    const config: AxiosRequestConfig = {url: `${this.url}/search?q=${encodeURI(title)}&type="albums"`, method: 'get', headers: this.headers};
    return this.apiCall(config).then(data => {
      return data;
    });
  }

  getAlbumTracks(albumUri: string): Promise<any> {
    const albumId = albumUri.substring(albumUri.lastIndexOf(':') + 1);
    const config: AxiosRequestConfig = {url: `${this.url}/album_tracks?id=${albumId}`,  method: 'get', headers: this.headers};
    return this.apiCall(config).then(data => {
      return data;
    });
  }
  
  getAlbumMetadata(id: string): Promise<any> {
    const config: AxiosRequestConfig = {url: `${this.url}/albums/?ids=${id}`, method: 'get', headers: this.headers};
    return this.apiCall(config).then(data => {
      return data.albums && data.albums.length > 0 ? data.albums[0] : null;
    });
  }

  getTrackMetadata(id: string): Promise<any> {
    const config: AxiosRequestConfig = {url: `${this.url}/tracks/?ids=${id}`, method: 'get', headers: this.headers};
    return this.apiCall(config).then(data => {
      return data.tracks && data.tracks.length > 0 ? data.tracks[0] : null;
    });
  }

  getArtistAlbums(artistId: string): Promise<any> {
    const config: AxiosRequestConfig = {url: `${this.url}/artist_albums/?id=${artistId}&offset=0&limit=100`, method: 'get', headers: this.headers};
    return this.apiCall(config);
  }
}