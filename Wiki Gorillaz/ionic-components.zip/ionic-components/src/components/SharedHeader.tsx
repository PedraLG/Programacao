import { IonHeader, IonTitle, IonToolbar, IonSearchbar, IonChip, IonAvatar, IonLabel, IonIcon } from '@ionic/react';
import './SharedHeader.css';
import { closeCircle } from 'ionicons/icons';

interface HeaderProps {
  title: string;
}

const SharedHeader: React.FC<HeaderProps> = ({title}) => {
  return (
    <IonHeader>
      <IonToolbar>
        <IonTitle>{title}</IonTitle>
      </IonToolbar>
      <IonToolbar>
        <IonSearchbar slot='start'></IonSearchbar>
        <IonChip slot='end'>
          <IonAvatar>
            <img alt="Silhouette of a person's head" src="https://ionicframework.com/docs/img/demos/avatar.svg" />
          </IonAvatar>
          <IonLabel>Avatar</IonLabel>
          <IonIcon icon={closeCircle}></IonIcon>
        </IonChip>
      </IonToolbar>
    </IonHeader>
  );
};

export default SharedHeader;
