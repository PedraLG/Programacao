import { IonContent, IonPage, IonList, IonItem, IonLabel, IonBadge, IonCard, IonCardHeader, IonCardTitle, IonCardSubtitle, IonCardContent, IonHeader, IonToolbar, IonTitle} from '@ionic/react';
import './Tab2.css';

const História: React.FC = () => {
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>História</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent className="tab2">
        <IonCard>
          <IonCardHeader>
            <IonCardTitle>Fase 1</IonCardTitle>
            <IonCardSubtitle>Gorillaz (1998-2002)</IonCardSubtitle>
          </IonCardHeader>
          <IonCardContent>
            A história dos Gorillaz começa em 1997, quando Murdoc Niccals, um músico fracassado e excêntrico, forma a banda após conhecer 2-D, um jovem que sofre dois acidentes provocados por ele e acaba tornando-se vocalista e tecladista do grupo. Juntos, instalam-se no misterioso Kong Studios, em Essex, e recrutam Russel Hobbs, um baterista possuído pelos espíritos de amigos mortos, e Noodle, uma prodigiosa guitarrista japonesa que surge misteriosamente enviada por encomenda.
          </IonCardContent>
          <IonCardContent>
            Com essa formação, os Gorillaz lançam seu primeiro EP Tomorrow Comes Today (2000) e, em 2001, o álbum de estreia Gorillaz, que inclui os sucessos Clint Eastwood e 19-2000. O projeto mistura animação, hip-hop, rock e eletrónica, tornando-se um fenómeno global. Durante as tours, o grupo enfrenta várias confusões e eventos bizarros, como a perda temporária do estúdio, brigas internas e experiências traumáticas para Noodle.
          </IonCardContent>
          <IonCardContent>
            Em 2002, após uma tentativa falhada de fazer um filme em Hollywood e o lançamento do álbum de remixes Laika Come Home, as tensões entre os membros culminam na separação da banda.
          </IonCardContent>
        </IonCard>
        <IonCard>
          <IonCardHeader>
            <IonCardTitle>Fase 1 - Teorias e Curiosidades</IonCardTitle>
            <IonCardSubtitle>Gorillaz (1998-2002)</IonCardSubtitle>
          </IonCardHeader>
          <IonCardContent>
            Origem bizarra da banda:
            Murdoc literalmente atropelou 2-D duas vezes antes de o recrutar para a banda. O nome “2-D” vem dos dois “dents” (amolgadelas) na cabeça dele — resultado direto dos acidentes!
          </IonCardContent>
          <IonCardContent>
            O fantasma do Del:
            Russel é possuído pelos espíritos dos seus amigos mortos num tiroteio em Nova Iorque. O mais famoso é o Del the Ghost Rapper, que aparece como fantasma azul no clipe de Clint Eastwood.
          </IonCardContent>
          <IonCardContent>
            Noodle e o mistério japonês:
            A guitarrista apareceu literalmente numa caixa da FedEx, sem memória e com uma guitarra nas mãos. Há teorias de que ela fazia parte de um programa militar japonês secreto de criação de músicos-prodígio.
          </IonCardContent>
          <IonCardContent>
            Kong Studios é assombrado:
            O estúdio onde a banda vive é cheio de referências a filmes de terror e está sempre rodeado de lixo, túmulos e monstros. Muitos fãs acreditam que Kong Studios é uma metáfora para a mente de Murdoc — caótica e sombria.
          </IonCardContent>
          <IonCardContent>
            “Laika Come Home” e os macacos do espaço:
            O álbum de remixes foi feito pelos Spacemonkeyz, três macacos mutantes que, segundo a lore, roubaram as fitas do primeiro disco para tentar contactar Laika, a cadela astronauta.
          </IonCardContent>
          <IonCardContent>
            O filme que nunca aconteceu:
            Durante o auge da fama, os Gorillaz tentaram fazer um filme em Hollywood chamado Whoops! There Goes My Career!, mas acabou cancelado por causa de brigas internas, festas demais e o caos clássico de Murdoc.
          </IonCardContent>
          <IonCardContent>
            Fim da fase 1:
            Tudo desmoronou depois de Murdoc tentar estrangular 2-D. Após isso, o grupo separou-se, deixando Kong Studios abandonado — o que, claro, só alimentou mais teorias e lendas urbanas.
          </IonCardContent>
        </IonCard>
        <IonCard>
          <IonCardHeader>
            <IonCardTitle>Fase 2</IonCardTitle>
            <IonCardSubtitle>Demon Days (2004–2008)</IonCardSubtitle>
          </IonCardHeader>
          <IonCardContent>
            Após a separação, cada membro segue caminhos próprios: Murdoc é preso no México, aprende um pouco de magia negra e ganha um corvo chamado Cortez; Noodle volta ao Japão para descobrir seu passado secreto como super-soldado; 2-D retorna à Inglaterra e trabalha na feira do pai, enquanto Russel se recupera em Los Angeles na casa de Ike Turner.
          </IonCardContent>
          <IonCardContent>
            Em 2003, Noodle retorna a Kong Studios, encontrando o prédio tomado por zumbis e monstros, e começa a escrever o conceito do álbum Demon Days. No início de 2004, Murdoc escapa da prisão, e os quatro membros se reúnem em março, iniciando a gravação do segundo álbum, com a ajuda de Damon Albarn e do produtor Danger Mouse.
          </IonCardContent>
          <IonCardContent>
            O álbum, lançado em 2005, reflete uma visão crítica e sombria do mundo pós-11 de setembro, incluindo hits como Feel Good Inc. e DARE. A banda realiza apresentações exclusivas, grava vídeos icônicos (El Mañana, Dirty Harry) e passa por eventos bizarros, como perseguições misteriosas e ataques durante a Demon Detour.
          </IonCardContent>
          <IonCardContent>
            Entre 2006 e 2007, Murdoc fica sozinho em Kong Studios, enfrenta ameaças sobrenaturais e coloca o estúdio à venda, culminando com a destruição do prédio em 2008.
          </IonCardContent>
        </IonCard>
        <IonCard>
          <IonCardHeader>
            <IonCardTitle>Fase 2 - Teorias e Curiosidades</IonCardTitle>
            <IonCardSubtitle>Demon Days (2004–2008)</IonCardSubtitle>
          </IonCardHeader>
          <IonCardContent>
            Murdoc e magia negra: Na prisão mexicana, ele aprendeu feitiços com os colegas de cela e ganhou um corvo chamado Cortez, que se tornou seu “colega de crime” e fonte de mistério.
          </IonCardContent>
          <IonCardContent>
            Noodle, a super soldado: O episódio do “Ocean Bacon” não é só estranho, é a chave para seu passado secreto. Ela foi parte de um programa governamental japonês que quase a matou, mas também a tornou fluente em inglês da noite para o dia.  
          </IonCardContent>
          <IonCardContent>
            Zumbis em Kong Studios: Quando Noodle voltou, o estúdio estava tomado por mortos-vivos e monstros… sim, os Gorillaz praticamente lidaram com apocalipse dentro do escritório deles.
          </IonCardContent>
          <IonCardContent>
            2-D e o ego renovado: Trabalhar na feira do pai não era só diversão; ele reaprendeu a se valorizar, fez amizade com Shane Lynch e finalmente começou a ver Murdoc de forma crítica.
          </IonCardContent>
          <IonCardContent>
            Demon Detour = perigo real: Durante a turnê de promoção do Demon Days, tiros misteriosos atingiam o ônibus da banda todas as noites. Suspeitos? Desde chefes do governo japonês até ex-fãs vingativos.
          </IonCardContent>
          <IonCardContent>
            El Mañana e Noodle desaparecida: O icônico vídeo do windmill não foi apenas um show de efeitos; na narrativa, Noodle desaparece em circunstâncias misteriosas, aumentando o mito da banda.
          </IonCardContent>
          <IonCardContent>
            Murdoc vs. o mundo: Entre inimigos sobrenaturais, mercenários e dívidas com o diabo, Murdoc se tornou praticamente um anti-herói global, sobrevivendo a tudo com caos e charme.
          </IonCardContent>
          <IonCardContent>
            Mistérios não resolvidos: Muitos fãs especulam que entidades como The Boogieman e a “Department Of Musical Corrections” ainda influenciam os eventos dos Gorillaz, mantendo o universo da banda cheio de suspense.
          </IonCardContent>
        </IonCard>
        <IonCard>
          <IonCardHeader>
            <IonCardTitle>Fase 3</IonCardTitle>
            <IonCardSubtitle>Plastic Beach (2008–2013)</IonCardSubtitle>
          </IonCardHeader>
          <IonCardContent>
            Durante esta fase, Murdoc descobre uma ilha feita de lixo no meio do oceano, chamada Plastic Beach, localizada em Point Nemo, o ponto mais distante de qualquer terra. Ele pinta a ilha de rosa, transforma-a na nova base da banda e começa a planear o terceiro álbum Plastic Beach, enquanto tenta reunir seus colegas de banda. Noodle desaparecida é substituída por uma versão ciborgue violenta, criada a partir de seu DNA, para servir como guarda-costas e guitarrista.
          </IonCardContent>
          <IonCardContent>
            2-D é sequestrado e levado para Plastic Beach, sofrendo depressão e abusos por parte de Murdoc e Cyborg Noodle. Russel, após ingerir toneladas de poluição, cresce enormemente, tornando-se gigante, simbolizando os efeitos destrutivos do homem sobre a natureza. Murdoc e 2-D viajam em carro-submarino para a ilha, dando origem ao icónico videoclipe de Stylo.
          </IonCardContent>
          <IonCardContent>
            O álbum Plastic Beach é lançado em março de 2010 com grande aclamação crítica, mas vendas modestas. A banda embarca numa “comeback tour”, incluindo Coachella, onde Murdoc é deportado e a banda ao vivo assume a performance. Singles como Superfast Jellyfish e On Melancholy Hill consolidam o sucesso do projeto, e Noodle reaparece após um período de desaparecimento, escondida e sobrevivendo a múltiplos perigos.
          </IonCardContent>
          <IonCardContent>
            Após ataques dos Black Clouds e confrontos com o Boogieman, a banda enfrenta várias ameaças, culminando na destruição parcial de Plastic Beach. Ao longo desta fase, eventos como o álbum The Fall (2010), feitos por 2-D em tour, e a colaboração em DoYaThing (2012) mostram a banda a trabalhar entre crises e escapadas. No final, conflitos internos e problemas legais levam à desagregação temporária da banda, com Murdoc sendo preso em “Dungeon Abbey”.
          </IonCardContent>
        </IonCard>
        <IonCard>
          <IonCardHeader>
            <IonCardTitle>Fase 3 - Teorias e Curiosidades</IonCardTitle>
            <IonCardSubtitle>Plastic Beach (2008–2013)</IonCardSubtitle>
          </IonCardHeader>
          <IonCardContent>
            Point Nemo e Plastic Beach:
            O local da ilha é inspirado no ponto mais remoto do oceano. A ideia de Gorillaz criar uma ilha feita de lixo simboliza a poluição e o consumo excessivo do homem, tema central do álbum.
          </IonCardContent>
          <IonCardContent>  
            Cyborg Noodle:
            Após o desaparecimento de Noodle, Murdoc cria uma versão ciborgue usando seu DNA. Alguns fãs acreditam que isso representa a perda da inocência artística e a manipulação da música por interesses comerciais.
          </IonCardContent>
          <IonCardContent>
            Russel gigante:
            Sua transformação reflete como a poluição e o excesso humano podem afetar a natureza, além de ser uma clara homenagem a Gulliver’s Travels.
          </IonCardContent>
          <IonCardContent>
            Bruce Willis na perseguição de Stylo:
            O cameo absurdo simboliza o caos e o surrealismo presentes nesta fase, reforçando a estética cinematográfica dos videoclipes.
          </IonCardContent>
          <IonCardContent>
            O Boogieman e os Black Clouds:
            Representam os obstáculos e pressões externas, como contratos musicais e dívidas, que Murdoc enfrenta constantemente.
          </IonCardContent>
          <IonCardContent>
            The Book of M.A.N.:
            Encontrado na ilha, narra a história da humanidade até Plastic Beach. Alguns fãs teorizam que ele conecta toda a narrativa das fases 1 a 3, servindo como linha condutora da ficção da banda.
          </IonCardContent>
          <IonCardContent>
            A destruição de Plastic Beach:
            Marca o fim simbólico de uma era da banda e o início de novas aventuras, ligando diretamente à Fase 4 (The Fall e Humanz). A ideia é que, mesmo quando tudo parece perdido, os membros sobrevivem e evoluem.
          </IonCardContent>
          <IonCardContent>
            Easter Eggs em videoclipes:
            Pequenos detalhes, como Russel salvando Noodle ou o “Massive Dick” (a baleia), mostram a atenção da banda aos detalhes de narrativa visual, recompensando fãs atentos.
          </IonCardContent>
          <IonCardContent>
            Teoria da “vida após a fase 3”:
            Muitos acreditam que a fase retrata um renascimento da banda, onde o caos de Plastic Beach prepara os personagens para confrontos e aventuras futuras, mantendo o tom satírico e crítico sobre a indústria musical.
          </IonCardContent>
        </IonCard>
        <IonCard>
          <IonCardHeader>
            <IonCardTitle>Fase 4</IonCardTitle>
            <IonCardSubtitle>Humanz (2014–2018)</IonCardSubtitle>
          </IonCardHeader>
          <IonCardContent>
            Dois anos e meio após a prisão de Murdoc Niccals, a indústria musical enfrentava uma crise e precisava desesperadamente de grandes músicos e compositores. Um representante da Entertainment Internal Affairs ofereceu a Murdoc a liberdade condicional em troca da gravação de um novo álbum, proposta que ele aceitou. Ao sair da prisão, Murdoc soube do show de Damon Albarn e The Heavy Seas no Royal Albert Hall e se mudou imediatamente para o Studio 13, em West London, sem avisar ninguém.
          </IonCardContent>
          <IonCardContent>
            Lá, reencontrou Russel Hobbs, que após deixar a banda em 2012, havia voltado aos EUA, se dedicado ao boxe e retornado à Inglaterra dois anos depois. Os dois assistiram ao show, ficaram impressionados com o novo baixista Seye Adelekan e, embora não quisessem se tornar amigos, decidiram retomar a música juntos.
          </IonCardContent>
          <IonCardContent>
            Enquanto isso, Noodle retornou ao Japão e retomou o mergulho de pérolas com Chiyoko. Acidentalmente, ela libertou Maazu, um demônio milenar aprisionado em uma pérola, e passou anos rastreando-o. Em Tóquio, Noodle encontrou Maazu disfarçado de humano no submundo criminoso, decapitou-o e enviou-se em uma caixa para West London, para se reunir com Murdoc e Russel.
          </IonCardContent>
          <IonCardContent>
            2-D, ainda na Inglaterra, soube da reunião da banda e partiu para um retiro silencioso no Himalaia para se preparar emocionalmente para reencontrar Murdoc. Murdoc e Russel começaram a trabalhar em novos demos no Studio 13. Noodle chegou logo depois, seguida de 2-D em 29 de julho de 2015. Durante esse período, os membros perceberam mudanças em Murdoc após a prisão, mostrando remorso por seus atos passados, mas ainda provocando os colegas de vez em quando. Assim, Gorillaz estava reunida e pronta para um novo álbum.
          </IonCardContent>
          <IonCardContent>
            Em 2016, a banda gravou o álbum Humanz, lançado em 2017, acompanhado do single Hallelujah Money. Murdoc organizou uma festa em Detroit, no “Spirit House”, cenário do vídeo de Saturnz Barz, onde cada membro enfrentava seu próprio demônio. Singles como Ascension, Andromeda e We Got the Power também foram lançados, seguidos de Let Me Out e The Apprentice.
          </IonCardContent>
          <IonCardContent>
            Em junho de 2017, 2-D lançou secretamente Sleeping Powder, gravado sozinho durante uma semana em que Murdoc estava em coma. A banda iniciou a turnê mundial Humanz Tour e organizou o Demon Dayz Festival em Margate. Novos integrantes ao vivo se juntaram à banda, incluindo antigos membros de turnês anteriores.
          </IonCardContent>
          <IonCardContent>
            Em agosto, o single Strobelite foi lançado, mostrando Murdoc interagindo com um homem misterioso em um clube, enquanto Noodle e 2-D se divertiam e Russel dormia. Pouco depois, Murdoc foi novamente preso em Londres, e a banda lançou a Humanz Super Deluxe Box Set, com faixas inéditas, e a revista G Magazine. Em fevereiro de 2018, Gorillaz ganhou o BRIT Award de Melhor Banda Britânica, com Murdoc recebendo o prêmio ao vivo diretamente da prisão.
          </IonCardContent>
        </IonCard>
        <IonCard>
          <IonCardHeader>
            <IonCardTitle>Fase 4 - Teorias e Curiosidades</IonCardTitle>
            <IonCardSubtitle>Humanz (2014–2018)</IonCardSubtitle>
          </IonCardHeader>
          <IonCardContent>
            Murdoc preso e redenção: A prisão de Murdoc marca um período de reflexão e mudança. Alguns fãs acreditam que sua experiência carcerária influenciou a atmosfera mais sombria e política de Humanz, mostrando que a banda também lida com erros e consequências.
          </IonCardContent>
          <IonCardContent>
            Reencontro de Russel e Murdoc: O reencontro tenso entre os dois no after-party simboliza que a banda funciona mais como projeto artístico do que como amizade pessoal. A decisão de fazer música juntos, mesmo sem retomar laços de amizade, reforça o tema de colaboração criativa acima de vínculos pessoais.
          </IonCardContent>
          <IonCardContent>
            Noodle e Maazu: O episódio de Noodle decapitando Maazu representa a luta contra demônios internos. Alguns fãs veem Maazu como uma metáfora para ameaças do passado ou obstáculos pessoais, e a entrega do pacote para Murdoc mostra a interconexão da banda, mesmo à distância.
          </IonCardContent>
          <IonCardContent>
            2-D no Himalaia: Sua viagem para o retiro silencioso simboliza preparação emocional e autocontrole. A excomunhão por falar demais reforça sua ingenuidade e curiosidade, contrastando com a astúcia de Murdoc.
          </IonCardContent>
          <IonCardContent>
            Studio 13 como núcleo criativo: O estúdio de Damon Albarn se torna o epicentro da banda, reunindo Murdoc, Russel, Noodle e 2-D. É um espaço que mistura estabilidade e renascimento, simbolizando um novo começo para a banda após períodos turbulentos.
          </IonCardContent>
          <IonCardContent>
            Festa Spirit House e demônios: Os demônios que assombram cada membro refletem vulnerabilidades individuais: Noodle enfrenta o terror, Russel a confusão interna e 2-D frustração e humor. Mostra a tendência da banda de misturar terror e fantasia em experiências musicais.
          </IonCardContent>
          <IonCardContent>
            Murdoc e marketing extremo: Mesmo preso, ele participa da promoção de Humanz e da revista G Magazine, reforçando seu papel de manipulador da imagem da banda. Alguns fãs interpretam isso como uma crítica à fama e ao controle midiático.
          </IonCardContent>
          <IonCardContent>
            Kool Klown Klan: O culto misterioso no Demon Dayz Festival e citado em Momentz sugere forças externas que observam a banda. Teóricos acreditam que é uma metáfora para pressões e influências da indústria musical.
          </IonCardContent>
          <IonCardContent>
            Sleeping Powder e independência de 2-D: O single gravado sozinho durante o coma de Murdoc é interpretado como um ato de rebeldia e autonomia artística, mostrando que 2-D pode se destacar sem depender dos outros membros.
          </IonCardContent>
          <IonCardContent>
            Prisões recorrentes de Murdoc: O ciclo de prisão e libertação simboliza padrões de transgressão e redenção, reforçando que a narrativa da banda é um drama contínuo de personagens animados com histórias complexas, refletindo a vida real de artistas e os altos e baixos da indústria musical.
          </IonCardContent>
        </IonCard>
        <IonCard>
          <IonCardHeader>
            <IonCardTitle>Fase 5</IonCardTitle>
            <IonCardSubtitle>The Now Now (2018–2019)</IonCardSubtitle>
          </IonCardHeader>
          <IonCardContent>
            Após o sucesso de Humanz (2017), os Gorillaz decidiram continuar o ritmo e lançaram The Now Now (2018), gravado durante a tour e com Ace, o vilão verde das Powerpuff Girls, a substituir Murdoc, preso por alegado contrabando. O álbum trouxe um som mais leve e introspectivo, refletindo um 2-D mais livre da influência de Murdoc, com singles como Humility, Tranz, Fire Flies e Hollywood. Enquanto o resto da banda viajava pelo mundo com a Now Now Tour, Murdoc tramava a fuga da prisão, alegando ter sido vítima de uma armadilha feita por um demónio chamado El Mierda.
          </IonCardContent>
          <IonCardContent>
            Convencida de que esse ser podia ter roubado a alma de 2-D, Noodle partiu sozinha para a Patagónia em busca de respostas, mas descobriu que Murdoc tinha inventado quase tudo: o “crime lord” era na verdade o dono de um spa de montanha e Murdoc fora preso apenas por multas de estacionamento. Depois de fingir a própria morte e reaparecer amarrado a um iaque, o baixista reconheceu os seus erros e prometeu mudar. A banda reuniu-se novamente para terminar a tour e encerrou o ano com a colaboração G-Shock Mission M101, uma mini-série de ficção científica feita em parceria com a Casio, culminando com o festival Demon Dayz 2018 em Los Angeles.
          </IonCardContent>
        </IonCard>
        <IonCard>
          <IonCardHeader>
            <IonCardTitle>Fase 5 - Teorias e Curiosidades</IonCardTitle>
            <IonCardSubtitle>The Now Now (2018–2019)</IonCardSubtitle>
          </IonCardHeader>
          <IonCardContent>
            Ace no lugar de Murdoc:
            Com Murdoc preso, o baixista temporário foi ninguém menos que Ace, o vilão verde das Powerpuff Girls. Muitos fãs acham que essa ligação foi uma brincadeira intencional com o passado “cartoon” da banda — e até uma referência à infância de Noodle, fã da série.
          </IonCardContent>
          <IonCardContent>
            2-D finalmente feliz?
            Durante The Now Now, 2-D aparece mais sorridente e confiante. Isso levou fãs a teorizar que ele estava “livre” da influência de Murdoc — ou que sua alma tinha sido roubada pelo demónio El Mierda, como Noodle suspeita na história oficial.
          </IonCardContent>
          <IonCardContent>
            O mistério de El Mierda:
            Murdoc afirma ter sido traído por esse “senhor do crime demoníaco”, mas depois descobre-se que era tudo invenção. Ainda assim, alguns acreditam que o verdadeiro El Mierda pode existir — um ser sobrenatural que manipula Murdoc e absorve a negatividade da banda.
          </IonCardContent>
          <IonCardContent>
            A fuga (literal) pelo esgoto:
            Murdoc tenta escapar da prisão pelos canos de esgoto e é dado como morto. Mais tarde, surge amarrado a um iaque chamado Madge. Fãs interpretam isso como uma metáfora do renascimento de Murdoc — ou da sua tendência para dramatizar tudo.
          </IonCardContent>
          <IonCardContent>
            Noodle e o retiro espiritual:
            A busca de Noodle por El Mierda termina num spa nas montanhas, o El Montaña Wellness Centre. Alguns veem isso como símbolo da paz interior que ela encontra ao perceber que o verdadeiro “demónio” é o próprio Murdoc.
          </IonCardContent>
          <IonCardContent>
            Cyborg Noodle e os “Rejects”:
            Durante o Demon Dayz Festival, estava previsto um concerto de abertura com uma banda chamada The Rejects, que incluía Cyborg Noodle. Como o show foi cancelado, fãs acreditam que Cyborg Noodle ainda anda por aí — talvez preparando um regresso sombrio.
          </IonCardContent>
          <IonCardContent>
            Missão intergaláctica G-Shock:
            A colaboração com a Casio virou uma mini-série onde os Gorillaz viajam pelo espaço para distribuir relógios. Alguns acham que isso representa o ciclo infinito da banda: morrer, renascer e continuar sempre “fora do tempo”.
          </IonCardContent>
        </IonCard>
        <IonCard>
          <IonCardHeader>
            <IonCardTitle>Fase 6</IonCardTitle>
            <IonCardSubtitle>Song Machine (2019–2021)</IonCardSubtitle>
          </IonCardHeader>
          <IonCardContent>
            Durante uma breve pausa em 2019, os membros dos Gorillaz espalharam-se pelo mundo e começaram a trocar postais entre si: Noodle, impressionada pelos efeitos das mudanças climáticas no Lago Urmia, expressou o desejo de construir uma máquina para “ver o mundo antes que desapareça”. 2-D respondeu de Beirute dizendo ter encontrado as peças para o projeto, enquanto Murdoc e Russel também enviaram mensagens das suas viagens. Pouco depois, essa misteriosa invenção — a Song Machine — foi ativada, marcando o início de uma nova fase do grupo.
          </IonCardContent>
          <IonCardContent>
            Lançada oficialmente em janeiro de 2020, Song Machine tornou-se uma série multimédia de faixas lançadas em episódios, com colaborações de artistas de todo o mundo. O novo estúdio da banda, renomeado Kong Studios West London, serviu como base para essas gravações. Entre viagens por portais, como em Désolé com Fatoumata Diawara, e aventuras absurdas, como o “projeto secreto” de Murdoc (uma cápsula pseudo-científica feita no porão), o grupo explorou a criatividade e o caos em plena pandemia, mantendo-se ativo mesmo em confinamento.
          </IonCardContent>
          <IonCardContent>
            Em outubro de 2020, lançaram Song Machine, Season One: Strange Timez, que reuniu colaborações com artistas como Elton John e The Cure. Os videoclipes mostravam os Gorillaz a viajar pela Lua, Los Angeles e até de volta a Plastic Beach, onde 2-D perdoa Murdoc e o salva da destruição da ilha. No ano seguinte, um colapso sobrenatural destruiu o novo Kong Studios, levando a banda a gravar na estrada o EP Meanwhile (2021), uma homenagem ao Notting Hill Carnival cancelado pela pandemia. Pouco depois, surgiram teorias sobre a enigmática “Department of Musical Corrections”, uma organização secreta que alegava tentar substituir os Gorillaz por clones, concluindo assim este capítulo de forma misteriosa e conspiratória.
          </IonCardContent>
        </IonCard>
        <IonCard>
          <IonCardHeader>
            <IonCardTitle>Fase 6 - Teorias e Curiosidades</IonCardTitle>
            <IonCardSubtitle>Song Machine (2019–2021)</IonCardSubtitle>
          </IonCardHeader>
          <IonCardContent>
            A máquina misteriosa:
            Tudo começou com postais trocados entre os membros, culminando na criação da Song Machine. Muitos fãs acreditam que a “máquina” simboliza o próprio processo criativo da banda — caótico, imprevisível e colaborativo.
          </IonCardContent>
          <IonCardContent>
            Viagem e colaborações:
            Durante Song Machine, cada música nasceu de uma “porta” aberta para outro lugar do mundo. Há quem diga que os portais representam os laços entre artistas e culturas, como se o estúdio fosse um centro interdimensional de música.
          </IonCardContent>
          <IonCardContent>
            Murdoc e a máquina orgónica:
            Enquanto os outros faziam música, Murdoc construiu uma “orgone accumulator” no porão — uma caixa mística inspirada em teorias pseudocientíficas. Fãs interpretam isso como um reflexo da paranoia e ego de Murdoc… e talvez um símbolo do isolamento durante a pandemia.
          </IonCardContent>
          <IonCardContent>
            A viagem à Lua:
            O clipe de Strange Timez mostra o grupo tentando destruir um outdoor lunar com a mensagem “Be The Change”. Muitos veem isso como uma crítica à cultura de consumo e ao estado do mundo pós-pandemia.
          </IonCardContent>
          <IonCardContent>
            O regresso a Plastic Beach:
            Em The Lost Chord, a banda revisita a ilha destruída da Fase 3. O momento em que 2-D salva Murdoc é visto como o fim simbólico da rivalidade entre eles — e o “fecho” de um ciclo emocional da banda.
          </IonCardContent>
          <IonCardContent>
            O caos no estúdio:
            O colapso do novo Kong Studios, engolido por um buraco infernal, foi interpretado como metáfora do fim da Song Machine e renascimento da banda. Já o EP Meanwhile trouxe uma mensagem de esperança e celebração da cultura negra britânica.
          </IonCardContent>
          <IonCardContent>
            A conspiração do D.M.C.:
            O aparecimento do “Department of Musical Corrections” levantou teorias de que a indústria tenta controlar os Gorillaz, substituindo-os por versões artificiais — uma metáfora da luta constante entre arte livre e o controlo corporativo.
          </IonCardContent>
        </IonCard>
        <IonCard>
          <IonCardHeader>
            <IonCardTitle>Fase 7</IonCardTitle>
            <IonCardSubtitle>Cracker Island (2022–2024)</IonCardSubtitle>
          </IonCardHeader>
          <IonCardContent>
            Em 2022, os Gorillaz iniciaram a World Tour 2022 e começaram a tocar músicas inéditas, compensando a falta de uma tour para Song Machine. Em julho, instalaram-se na Silver Lake Mansion em Los Angeles para gravar um novo álbum enquanto o antigo Kong Studios era restaurado. Nesse período, Murdoc mergulhou no ocultismo e fundou um culto chamado The Last Cult, proclamando-se “O Grande Líder” e nomeando 2-D como “O Escolhido”. 2-D começou um podcast relatando as atividades bizarras do grupo — cavar buracos, pintar um obelisco e conviver com a misteriosa vizinha “Moon Flower”, por quem Murdoc rapidamente se apaixonou.
          </IonCardContent>
          <IonCardContent>
            Enquanto isso, o papel de “Buscador da Verdade” foi atribuído a Russel, que começou a receber transmissões estranhas datadas de 1923, 1948, 1973 e 1998, revelando um ciclo de 25 anos e prevendo um evento sobrenatural em 2023 chamado The Rupture. Noodle, “A Erudita”, começou a desconfiar do rumo das coisas, especialmente quando descobriu que Moon Flower era na verdade a sacerdotisa de outro culto, The Forever Cult, e que planeava sacrificar 2-D num ritual ancestral. O grupo conseguiu chegar a tempo de impedir o sacrifício, mas um acidente com o perfume de Murdoc causou a explosão do monstro do ritual, quebrando o ciclo e provocando The Rupture.
          </IonCardContent>
          <IonCardContent>
            Após o caos, a polícia de Los Angeles prendeu a banda, cumprindo a previsão vista nas transmissões. Moon Flower reviveu brevemente e, envelhecendo rapidamente, passou seus últimos dias ao lado de Murdoc, revelando que ajudou a banda a escapar do sacrifício e que via em 2-D uma pureza que o tornava “intocável”. Ela morreu transformando-se em cinzas, deixando-as com Murdoc como lembrança. Em fevereiro de 2023, o grupo lançou Cracker Island, que se tornou o primeiro álbum nº1 do Gorillaz desde Demon Days, simbolizando o renascimento da banda após o colapso espiritual da era anterior.
          </IonCardContent>
          <IonCardContent>
            Poucos meses depois, anunciaram a mini-turnê The Getaway Shows, marcada para setembro de 2023 com participações especiais de Kaytranada, Lil Yachty e Remi Wolf. No entanto, a tour foi cancelada após um mandado de busca da polícia no Silver Lake Mansion, obrigando a banda a fugir para Nova Iorque e depois para Mumbai, encerrando a Fase Sete em clima de mistério e fuga.
          </IonCardContent>
        </IonCard>
        <IonCard>
          <IonCardHeader>
            <IonCardTitle>Fase 7 - Teorias e Curiosidades</IonCardTitle>
            <IonCardSubtitle>Cracker Island (2022–2024)</IonCardSubtitle>
          </IonCardHeader>
          <IonCardContent>
            O culto de Murdoc:
            O Last Cult pode ser interpretado como uma metáfora do fanatismo e da necessidade de Murdoc por controle e adoração. Fãs notaram paralelos entre o culto e a própria natureza dos fandoms online — cegamente devotos a figuras carismáticas.
          </IonCardContent>
          <IonCardContent>
            O podcast de 2-D:
            Os áudios de 2-D em The Last Cult Chronicles revelam uma versão mais inocente e introspectiva dele. Muitos acreditam que o podcast representa o processo de autodescoberta do personagem, ou até uma tentativa de “acordar” do controlo de Murdoc.
          </IonCardContent>
          <IonCardContent>
            As transmissões misteriosas:
            Os vídeos da Static Channel, com imagens de Los Angeles em 1923, levantaram teorias sobre viagens no tempo e loops dimensionais. O ciclo de 25 anos é visto como uma forma de o Gorillaz comentar os próprios “renascimentos” criativos ao longo das fases.
          </IonCardContent>
          <IonCardContent>
            Moon Flower e Lady Hollodown:
            A ligação entre Moon Flower e a atriz dos anos 1920 sugere que o Forever Cult manipula o tempo e a fama — uma crítica às indústrias do entretenimento que sacrificam artistas pela imortalidade mediática.
          </IonCardContent>
          <IonCardContent>
            O perfume que causou o apocalipse:
            Murdoc literalmente salvou o mundo por acidente, ao deixar cair o seu perfume no poço ritual. Fãs brincam dizendo que é a prova de que “o ego de Murdoc é tão tóxico que explode demónios”.
          </IonCardContent>
          <IonCardContent>
            A redenção de Murdoc:
            O romance trágico com Moon Flower mostrou um lado vulnerável de Murdoc. Muitos interpretam a sua morte em cinzas como o encerramento simbólico do arco de redenção dele — finalmente confrontando a perda e o amor verdadeiro.
          </IonCardContent>
          <IonCardContent>
            A prisão e a fuga:
            O final da fase, com o grupo preso e depois fugindo da polícia, é visto como uma referência ao ciclo eterno de ruína e renascimento do Gorillaz — cada fase termina em caos, mas abre caminho para uma nova transformação.
          </IonCardContent>
        </IonCard>
      </IonContent>
    </IonPage>
  );
};

export default História;
