import {IonContent, IonPage, IonButton, IonHeader, IonTitle, IonList, IonItem, IonToolbar, IonSearchbar, IonThumbnail, IonLabel, IonNote, IonBadge, IonGrid, IonRow, IonCol, IonCard, IonImg, IonCardHeader, IonCardTitle, IonModal, IonButtons, IonIcon, IonSpinner, IonText, IonCardSubtitle, IonCardContent, IonListHeader} from '@ionic/react';
import './Tab3.css';
import React, { useMemo, useState } from 'react';
import { searchCircle, close, calendarOutline, pricetagOutline, musicalNotes, timeOutline, personOutline, alertCircleOutline, filter, barChartOutline, trashOutline, addCircleOutline, listOutline, statsChart } from 'ionicons/icons';
import { SpotifyService } from '../services/spotify.service';
import {Chart} from 'react-google-charts';

const s = new SpotifyService();
const id_Gorillaz = "3AA28KZvwAUcZuOKwyblJQ";

const Música: React.FC = () => {
  const [titleSearch, setTitleSearch] = React.useState('');
  const [tracks, setTracks] = React.useState([{data: {name: "1", id: "2", uri: "3", albumOfTrack: {uri: "1", name: "2", coverArt: {sources: {1: {url: "1"}, 2: {url: "1"}}}}, artists: {items: [{profile: {name: "1"}}]}}}]);
  const [albums, setAlbums] = React.useState([{data: {name: "1", uri: "2", coverArt: {sources: {1: {url: "1"}, 2: {url: "1"}}}, artists: {items: [{profile: {name: "1"}}]}}}]);
  const [artistAlbums, setArtistAlbums] = React.useState<any[]>([]);
  const [selectedAlbum, setSelectedAlbum] = React.useState<any>({data: {name: "", uri: "", coverArt: {sources: [{url: ""}]}, artists: {items: [{profile: {name: ""}}]}}});
  const [albumTracks, setAlbumTracks] = React.useState<any[]>([]);
  const [showModal, setShowModal] = React.useState(false);
  const [detailItem, setDetailItem] = React.useState<any>(null);
  const [loadingDetails, setLoadingDetails] = React.useState(false);
  const [isCompareMode, setIsCompareMode] = React.useState(false);
  const [compareList, setCompareList] = React.useState<any[]>([]);
  const [currentMetric, setCurrentMetric] = useState<'popularity' | 'tracks' | 'date'>('popularity');

  const isAlbumSelected = selectedAlbum.data.uri !== "";
  const isSearching = titleSearch.length > 0;

  const msToTime = (duration: number) => {if (!duration) return "N/A";
    const minutes = Math.floor(duration / 60000);
    const seconds = ((duration % 60000) / 1000).toFixed(0);
    return minutes + ":" + (Number(seconds) < 10 ? '0' : '') + seconds;
  };

  const getIdFromUri = (input: any) => {
    if (!input) return "";
    if (typeof input === 'string') {
        return input.includes(':') ? input.split(':').pop() : input;
    }
    const uri = input.uri || input.data?.uri;
    const id = input.id || input.data?.id;
    
    if (id) return id;
    if (uri) return uri.split(':').pop();
    
    return "";
  };

  const addToCompare = async (item: any, type: 'track' | 'album') => {
    const id = getIdFromUri(item);
    if (compareList.find(i => i.id === id)) return;

    let popularity = item.popularity;
    let name = item.name || item.data?.name;
    let release_date = item.release_date || item.album?.release_date || "0000";
    let total_tracks = item.total_tracks || 1;
    
    if (type === 'album' || popularity === undefined || !item.release_date) {
        try {
            const data = type === 'album' 
                ? await s.getAlbumMetadata(id) 
                : await s.getTrackMetadata(id);
            
            if (data) {
                popularity = data.popularity;
                name = data.name;
                
                if (type === 'album') {
                    release_date = data.release_date;
                    total_tracks = data.total_tracks;
                } else {
                    release_date = data.album?.release_date;
                    total_tracks = 1;
                }
            } else {
                popularity = 0;
            }
        } catch (e) {
            popularity = 0;
        }
    }

    const numPopularity = Number(popularity) || 0;
    const color = type === 'track' ? '#eb4444ff' : '#ffc409';
    
    setCompareList([...compareList, {
        id: id, 
        name: name, 
        popularity: numPopularity, 
        total_tracks: Number(total_tracks),
        release_date: release_date,
        type: type, 
        color: color
    }]);
  };

  const removeFromCompare = (id: string) => {
    setCompareList(compareList.filter(i => i.id !== id));
  };

  const data = useMemo(() => {
    let vLabel = "Valor";
    if (currentMetric === 'popularity') vLabel = "Popularidade (0-100)";
    if (currentMetric === 'tracks') vLabel = "Nº Faixas";
    if (currentMetric === 'date') vLabel = "Ano Lançamento";

    return [
        ["Elemento", vLabel, { role: "style" }],
        ...compareList.map(item => {
            let val = 0;
            if (currentMetric === 'popularity') {
                val = item.popularity;
            } else if (currentMetric === 'tracks') {
                val = item.total_tracks;
            } else if (currentMetric === 'date') {
                val = parseInt(item.release_date?.split('-')[0] || '0');
            }

            return [
                item.name || "Desconhecido", 
                val, 
                item.color || "silver"
            ];
        })
    ];
  }, [compareList, currentMetric]);

  const options = useMemo(() => {
    let viewWindowOption = undefined;
    if (currentMetric === 'popularity') {
        viewWindowOption = { min: 0, max: 100 };
    } else if (currentMetric === 'date') {
        const years = compareList.map(i => parseInt(i.release_date?.split('-')[0] || '0')).filter(y => y > 0);
        const minYear = years.length > 0 ? Math.min(...years) : 2000;
        viewWindowOption = { min: minYear - 2, max: undefined };
    }
    return {
        backgroundColor: 'transparent',
        legend: {position: "none"},
        vAxis: {
            title: currentMetric === 'popularity' ? 'Popularidade' : (currentMetric === 'tracks' ? 'Nº Faixas' : 'Ano'),
            titleTextStyle: {color: '#ffffff'}, 
            textStyle: {color: '#ffffff'}, 
            gridlines: { color: '#333333' },
            viewWindow: viewWindowOption
        },
        hAxis: {
            textStyle: {color: '#ffffff', fontSize: 11},
            slantedText: true,
            slantedTextAngle: 45 
        },
        chartArea: { width: '85%', height: '65%' },
        tooltip: { trigger: 'none' }, 
        enableInteractivity: false
    };
  }, [currentMetric, compareList]);

  const openDetails = (id: string, type: 'album' | 'track') => {
    setLoadingDetails(true);
    setShowModal(true);
    setDetailItem(null);

    if (type === 'album') {
        s.getAlbumMetadata(id).then(data => {
            setDetailItem({ ...data, type: 'album' });
            setLoadingDetails(false);
        });
    } else {
        s.getTrackMetadata(id).then(data => {
            setDetailItem({ ...data, type: 'track' });
            setLoadingDetails(false);
        });
    }
  };

  const loadArtistAlbums = () => {
    s.getArtistAlbums(id_Gorillaz).then(a => {
        const items = a.data?.artist_albums?.items || a.data?.artist?.discography?.albums?.items || [];
        const flatAlbums = items.map((item: any) => {
            return item.releases?.items?.[0] || item; 
        }).filter((item: any) => item !== undefined);
        
        setAlbums(flatAlbums);
    }).catch(err => console.error("Erro:", err));
  };

  const sortAlbums = (type: 'date' | 'alfabetico') => {
    const sorted = [...albums];
    if (type === 'date') {
        sorted.sort((a: any, b: any) => {
            const yearA = a.date?.year || a.data?.date?.year || 0;
            const yearB = b.date?.year || b.data?.date?.year || 0;
            return yearB - yearA;
        });
    } else {
        sorted.sort((a: any, b: any) => {
            const nameA = a.name || a.data?.name || "";
            const nameB = b.name || b.data?.name || "";
            return nameA.localeCompare(nameB);
        });
    }
    setAlbums(sorted);
  };

  React.useEffect(() => {
    if (titleSearch.trim() !== '') {
      s.searchTracks(titleSearch).then(data => setTracks(data.tracks.items));
      s.searchAlbums(titleSearch).then(data => setAlbums(data.albums.items));
    } else {
      if (artistAlbums.length > 0) {
          setAlbums(artistAlbums);
      } else {
          loadArtistAlbums();
      }
      setTracks([]);
    }
  }, [titleSearch]);
  
  React.useEffect(() => {
    loadArtistAlbums();
  }, []);

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Música</IonTitle>
          <IonButtons slot="end">
            <IonButton 
                fill="solid"
                color={isCompareMode ? "tertiary" : "primary"} 
                onClick={() => {
                    setIsCompareMode(!isCompareMode);
                    setTitleSearch('');
                    setSelectedAlbum({data: {name: "", uri: ""}});
                  }}>
                <IonIcon slot="start" icon={isCompareMode ? listOutline : barChartOutline} />
                {isCompareMode ? "Detalhes" : "Comparar"}
            </IonButton>
          </IonButtons>
        </IonToolbar>
      </IonHeader>

      <IonContent className="tab3">
        <IonSearchbar className="search-bar" searchIcon={searchCircle} animated={true} placeholder="O que queres ouvir?" mode="ios"
          onIonChange={e => {
            if (e.detail.value === undefined) return;
            setTitleSearch(e.detail.value!);}}/>

        {!isCompareMode && !isSearching && !isAlbumSelected && (
            <IonToolbar className="sort-toolbar">
                <IonButtons slot="start">
                    <IonButton color="medium" onClick={() => sortAlbums('date')}>
                        <IonIcon slot="start" icon={calendarOutline} />
                        Data
                    </IonButton>
                    <IonButton color="medium" onClick={() => sortAlbums('alfabetico')}>
                        <IonIcon slot="start" icon={filter} />
                        A-Z
                    </IonButton>
                </IonButtons>
            </IonToolbar>
        )}

        {isCompareMode && !isSearching && (
            <IonGrid className="compare-grid">
                <IonRow className="compare-row">
                    <IonCol size="12" size-lg="8" className="compare-col">
                        <IonCard className="dashboard-card">
                            <IonCardHeader>
                                <IonCardTitle>Comparador</IonCardTitle>
                                <IonCardSubtitle>
                                    {currentMetric === 'popularity' && "Popularidade no Spotify"}
                                    {currentMetric === 'tracks' && "Número de Faixas"}
                                    {currentMetric === 'date' && "Ano de Lançamento"}
                                </IonCardSubtitle>
                            </IonCardHeader>
                            <IonCardContent className="card-content-flex">
                                {compareList.length > 0 ? (
                                    <>
                                        <div className="chart-container-fix">
                                            <Chart
                                                chartType="ColumnChart"
                                                width="100%"
                                                height="100%"
                                                data={data}
                                                options={options}
                                            />
                                        </div>

                                        <div className="metrics-toolbar">
                                            <IonButton size="small" fill={currentMetric === 'popularity' ? 'solid' : 'outline'} onClick={() => setCurrentMetric('popularity')}>
                                                <IonIcon slot="start" icon={statsChart} />
                                                Popularidade
                                            </IonButton>
                                            <IonButton size="small" fill={currentMetric === 'tracks' ? 'solid' : 'outline'} onClick={() => setCurrentMetric('tracks')}>
                                                <IonIcon slot="start" icon={listOutline} />
                                                Faixas
                                            </IonButton>
                                            <IonButton size="small" fill={currentMetric === 'date' ? 'solid' : 'outline'} onClick={() => setCurrentMetric('date')}>
                                                <IonIcon slot="start" icon={calendarOutline} />
                                                Data
                                            </IonButton>
                                        </div>
                                    </>
                                ) : (
                                    <div className="empty-state">
                                        <IonIcon icon={barChartOutline} />
                                        <IonText>Pesquisa e adiciona itens.</IonText>
                                    </div>
                                )}
                            </IonCardContent>
                        </IonCard>
                    </IonCol>

                    <IonCol size="12" size-lg="4" className="compare-col">
                        <IonCard className="dashboard-card">
                             <IonCardHeader>
                                <IonCardTitle style={{fontSize: '1.2rem'}}>Itens Selecionados</IonCardTitle>
                            </IonCardHeader>
                            <IonCardContent className="card-content-flex" style={{overflowY: 'auto'}}>
                                {compareList.length > 0 ? (
                                    <IonList className="compare-list">
                                        {compareList.map(item => (
                                            <IonItem key={item.id} lines="full" style={{'--background': 'transparent'}}>
                                                <div className="compare-item-wrapper">
                                                    <IonLabel className="compare-item-text">
                                                      {item.name}
                                                    </IonLabel>
                                                    
                                                    <div style={{display: 'flex', alignItems: 'center'}}>
                                                        <IonBadge color={item.type === 'track' ? 'danger' : 'warning'} style={{marginRight: '10px'}}>
                                                            {currentMetric === 'popularity' && item.popularity}
                                                            {currentMetric === 'tracks' && item.total_tracks}
                                                            {currentMetric === 'date' && (item.release_date?.split('-')[0] || 'N/A')}
                                                        </IonBadge>
                                                        <IonButton fill="clear" color="medium" onClick={() => removeFromCompare(item.id)}>
                                                            <IonIcon icon={trashOutline} />
                                                        </IonButton>
                                                    </div>
                                                </div>
                                            </IonItem>
                                        ))}
                                    </IonList>
                                ) : (
                                    <div className="empty-state">
                                        <IonText color="medium"><small>A lista está vazia.</small></IonText>
                                    </div>
                                )}
                            </IonCardContent>
                        </IonCard>
                    </IonCol>
                </IonRow>
            </IonGrid>
        )}

        {isSearching ? (
          <IonList>
            {albums.filter(a => a?.data?.artists?.items?.[0]?.profile?.name === "Gorillaz").length === 0 &&
              tracks.filter(a => a?.data?.artists?.items?.[0]?.profile?.name === "Gorillaz").length === 0 && (
                <IonItem lines="none">
                  <IonLabel className="no-results">
                    {titleSearch.length <= 5
                      ? "Nenhum resultado encontrado, adiciona mais letras."
                      : "Nenhum resultado encontrado."}
                  </IonLabel>
                </IonItem>
              )}
            {albums.filter(a => a?.data?.artists?.items?.[0]?.profile?.name === "Gorillaz")
                .map(a => (
                  <IonItem key={a.data['uri']}>
                    <IonThumbnail slot="start">
                      <IonImg src={a.data?.coverArt?.sources?.[1]?.url || 'assets/no-cover.png'} />
                    </IonThumbnail>
                    <IonLabel>
                      {a.data['name']}
                      <IonNote color="medium">{a.data.artists?.items?.[0]?.profile?.name || ""}</IonNote>
                    </IonLabel>
                    <IonBadge color="warning">Álbum</IonBadge>
                    {isCompareMode ? (
                        <IonButton slot="end" color="warning" fill="outline" onClick={() => addToCompare(a.data, 'album')}>
                            Comparar
                            <IonIcon slot="end" icon={addCircleOutline} />
                        </IonButton>
                    ) : (
                        <>
                            <IonButton fill="clear" onClick={() => openDetails(getIdFromUri(a.data.uri), 'album')}>Detalhes</IonButton>
                            <IonButton color="success" slot="end" href={`https://open.spotify.com/album/${a.data['uri']}`} target="_blank">Spotify</IonButton>
                        </>
                    )}
                  </IonItem>
              ))}
            {tracks.filter(a => a?.data?.artists?.items?.[0]?.profile?.name === "Gorillaz")
                .map(a => (
                  <IonItem key={a.data['id']}>
                    <IonThumbnail slot="start">
                      <IonImg src={a.data?.albumOfTrack?.coverArt?.sources?.[1]?.url || 'assets/no-cover.png'} />
                    </IonThumbnail>
                    <IonLabel>
                      {a.data['name']}
                      <IonNote color="medium">{a.data.artists?.items?.[0]?.profile?.name || ""}</IonNote>
                    </IonLabel>
                    <IonBadge color="danger">Música</IonBadge>
                    {isCompareMode ? (
                        <IonButton slot="end" color="danger" fill="outline" onClick={() => addToCompare(a.data, 'track')}>
                            Comparar
                            <IonIcon slot="end" icon={addCircleOutline} />
                        </IonButton>
                    ) : (
                        <>
                            <IonButton fill="clear" onClick={() => openDetails(a.data.id, 'track')}>Detalhes</IonButton>
                            <IonButton color="success" slot="end" href={`https://open.spotify.com/track/${a.data['id']}`} target="_blank">Spotify</IonButton>
                        </>
                    )}
                  </IonItem>
              ))}
          </IonList>

          ) : isAlbumSelected && !isCompareMode ? (
            <IonList>
              <IonCard className="album-header-card">
                  <div className="album-header-center">
                      <IonImg className="album-header-img" src={selectedAlbum.data.coverArt?.sources?.[0]?.url || 'assets/no-cover.png'}/>
                      <IonText className="album-header-title">{selectedAlbum.data.name}</IonText>
                      <IonText className="album-header-subtitle">Gorillaz</IonText>
                      
                      <div className="album-header-buttons">
                          <IonButton color="medium" fill="outline" onClick={() => openDetails(getIdFromUri(selectedAlbum.data.uri), 'album')}>
                              Detalhes
                          </IonButton>
                          
                          <IonButton color="success" href={`https://open.spotify.com/album/${selectedAlbum.data.uri}`} target="_blank">
                              Spotify
                          </IonButton>
                      </div>
                  </div>
              </IonCard>
              
              {albumTracks && albumTracks.length > 0 ? (
                albumTracks.map((item: any) => (
                  <IonItem key={item.track?.id || Math.random()}>
                    <IonThumbnail slot="start">
                      <IonImg src={selectedAlbum.data.coverArt?.sources?.[0]?.url || 'assets/no-cover.png'} />
                    </IonThumbnail>

                    <IonLabel>
                      <IonText className="list-item-title">{item.track?.name}</IonText>
                      <IonText color="medium" style={{fontSize: '0.8rem'}}>
                          {msToTime(item.track?.duration_ms || item.track?.duration?.totalMilliseconds)}
                      </IonText>
                    </IonLabel>

                    <IonBadge color="danger" style={{ marginRight: '5px' }}>Música</IonBadge>
                    
                    <IonButton fill="clear" onClick={() => openDetails(getIdFromUri(item.track), 'track')}>
                        Detalhes
                    </IonButton>

                    <IonButton color="success" slot="end" href={`https://open.spotify.com/track/${getIdFromUri(item.track)}`} target="_blank">
                      Ver
                    </IonButton>
                  </IonItem>
                ))
              ) : (
                <IonItem lines="none">
                  <IonLabel>A carregar músicas...</IonLabel>
                </IonItem>
              )}

              <IonButton expand="full" color="medium" onClick={() => {setSelectedAlbum({data: {name: "", uri: "", coverArt: {sources: [{url: ""}]}, artists: {items: [{profile: {name: ""}}]}}}); setAlbumTracks([]);
              }}>
                Voltar aos álbuns
              </IonButton>
            </IonList>
          ) : !isCompareMode && (
            <IonGrid>
              <IonRow>
                  {albums.map((a: any) => {
                      const uri = a.data?.uri || a.uri;
                      const name = a.data?.name || a.name;
                      return (
                          <IonCol size="6" key={uri}>
                              <IonCard onClick={() => {
                                  const normalizedAlbum = {data: {uri: uri, name: name, coverArt: { sources: [{url: a.coverArt?.sources?.[0]?.url || a.data?.coverArt?.sources?.[0]?.url || 'assets/no-cover.png'}] },artists: { items: [{profile: {name: "Gorillaz"}}] }}};
                                  setSelectedAlbum(normalizedAlbum);
                                  
                                  s.getAlbumTracks(uri).then(a => {
                                      const rawData = a.data || a;
                                      setAlbumTracks(rawData?.album?.tracks?.items || []);
                                  });
                              }}>
                                  <IonImg className="grid-img" src={a.coverArt?.sources?.[0]?.url || a.data?.coverArt?.sources?.[0]?.url || 'assets/no-cover.png'} />
                                  <IonCardHeader>
                                      <IonCardTitle>{name}</IonCardTitle>
                                  </IonCardHeader>
                              </IonCard>
                          </IonCol>
                      );
                  })}
              </IonRow>
          </IonGrid>
          )}

          <IonModal isOpen={showModal} onDidDismiss={() => setShowModal(false)}>
            <IonHeader>
                <IonToolbar>
                    <IonTitle>Detalhes</IonTitle>
                    <IonButtons slot="end"><IonButton onClick={() => setShowModal(false)}><IonIcon icon={close} /></IonButton></IonButtons>
                </IonToolbar>
            </IonHeader>
            <IonContent className="ion-padding">
                {loadingDetails ? (
                    <IonGrid className="loading-grid">
                        <IonRow><IonCol className="ion-text-center"><IonSpinner name="crescent" color="primary" /></IonCol></IonRow>
                    </IonGrid>
                ) : detailItem && (
                    <IonGrid>
                        <IonRow>
                            <IonCol className="modal-content-grid">
                                <IonImg
                                    className="modal-cover-img"
                                    src={detailItem.images?.[0]?.url || detailItem.album?.images?.[0]?.url || 'assets/no-cover.png'}
                                />
                                <IonText className="modal-main-title">
                                    {detailItem.name}
                                </IonText>

                                <IonText className="modal-artist-subtitle">
                                    {detailItem.artists?.[0]?.name || "Gorillaz"}
                                </IonText>

                                <IonList style={{ width: '100%' }}>
                                    {detailItem.type === 'album' && (
                                        <>
                                            <IonItem>
                                                <IonIcon icon={calendarOutline} slot="start" color="medium" />
                                                <IonLabel><IonText className="detail-key">Lançamento</IonText></IonLabel>
                                                <IonNote slot="end" className="detail-value-note">{detailItem.release_date}</IonNote>
                                            </IonItem>
                                            <IonItem>
                                                <IonIcon icon={pricetagOutline} slot="start" color="medium" />
                                                <IonLabel><IonText className="detail-key">Editora</IonText></IonLabel>
                                                <IonNote slot="end" className="detail-value-note">{detailItem.label}</IonNote>
                                            </IonItem>
                                            <IonItem>
                                                <IonIcon icon={musicalNotes} slot="start" color="medium" />
                                                <IonLabel><IonText className="detail-key">Total Faixas</IonText></IonLabel>
                                                <IonNote slot="end" className="detail-value-note">{detailItem.total_tracks}</IonNote>
                                            </IonItem>
                                            {detailItem.copyrights && detailItem.copyrights[0] && (
                                                <IonItem lines="none">
                                                    <IonLabel className="ion-text-wrap">
                                                        <IonText className="copyright-text">{detailItem.copyrights[0].text}</IonText>
                                                    </IonLabel>
                                                </IonItem>
                                            )}
                                        </>
                                    )}

                                    {detailItem.type === 'track' && (
                                        <>
                                            <IonItem>
                                                <IonIcon icon={musicalNotes} slot="start" color="medium" />
                                                <IonLabel><IonText className="detail-key">Álbum</IonText></IonLabel>
                                                <IonNote slot="end" className="detail-value-note">{detailItem.album?.name}</IonNote>
                                            </IonItem>
                                            <IonItem>
                                                <IonIcon icon={timeOutline} slot="start" color="medium" />
                                                <IonLabel><IonText className="detail-key">Duração</IonText></IonLabel>
                                                <IonNote slot="end" className="detail-value-note">{msToTime(detailItem.duration_ms)}</IonNote>
                                            </IonItem>
                                            <IonItem>
                                                <IonIcon icon={personOutline} slot="start" color="medium" />
                                                <IonLabel><IonText className="detail-key">Popularidade</IonText></IonLabel>
                                                <IonNote slot="end" className="detail-value-note">{detailItem.popularity}%</IonNote>
                                            </IonItem>
                                            <IonItem lines="none">
                                                <IonIcon icon={alertCircleOutline} slot="start" color={detailItem.explicit ? 'danger' : 'medium'} />
                                                <IonLabel><IonText className="detail-key">Conteúdo</IonText></IonLabel>
                                                <IonBadge slot="end" color={detailItem.explicit ? 'danger' : 'success'}>
                                                    {detailItem.explicit ? "Explícito" : "Geral"}
                                                </IonBadge>
                                            </IonItem>
                                        </>
                                    )}
                                </IonList>

                                {detailItem.external_urls?.spotify && (
                                <IonButton expand="block" color="success" className="spotify-btn" href={detailItem.external_urls?.spotify} target="_blank">
                                    Ouvir no Spotify
                                </IonButton>
                                )}
                            </IonCol>
                        </IonRow>
                    </IonGrid>
                )}
            </IonContent>
          </IonModal>
      </IonContent>
    </IonPage>
  );
};

export default Música;