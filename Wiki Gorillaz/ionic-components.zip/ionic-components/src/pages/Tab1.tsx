import { IonCol, IonContent, IonGrid, IonList,IonItem,IonLabel, IonHeader, IonPage, IonRow, IonTitle, IonToolbar, IonCard, IonCardHeader, IonCardTitle, IonCardSubtitle, IonCardContent, IonAccordionGroup, IonAccordion, IonListHeader, IonImg, IonNote } from '@ionic/react';
import './Tab1.css';
import { Chart } from "react-google-charts";

const Membros: React.FC = () => {
  const columns = [
    {type: "string", id: "Membro"},
    {type: "string", id: "Estado"},
    {type: "string", role: "style"},
    {type: "date", id: "Inicio"},
    {type: "date", id: "Fim"},
  ];

  const rows = [
    ["Damon Albarn", "Criador & Voz", "#7d7d7d", new Date(1998, 0, 1), new Date(2024, 0, 1)],
    ["Jamie Hewlett", "Criador & Arte", "#7d7d7d", new Date(1998, 0, 1), new Date(2024, 0, 1)],
    ["Remi Kabaka Jr.", "Voz (Russel) & Bateria", "#7d7d7d", new Date(1998, 0, 1), new Date(2024, 0, 1)],
    ["Mike Smith", "Teclas (Live)", "#505050", new Date(2001, 0, 1), new Date(2024, 0, 1)],

    ["2-D", "Na Banda", "#3dc2ff", new Date(1998, 0, 1), new Date(2024, 0, 1)],

    ["Murdoc", "Na Banda", "#2fdf75", new Date(1998, 0, 1), new Date(2018, 5, 1)],
    ["Murdoc", "Prisão (Ausente)", "#e0ac08", new Date(2018, 5, 1), new Date(2018, 9, 1)],
    ["Murdoc", "Na Banda", "#2fdf75", new Date(2018, 9, 1), new Date(2024, 0, 1)],

    ["Russel", "Na Banda", "#ffc409", new Date(1998, 0, 1), new Date(2002, 0, 1)],
    ["Russel", "Ausente (Exorcismo)", "#e0c9c9", new Date(2002, 0, 1), new Date(2004, 0, 1)],
    ["Russel", "Na Banda", "#ffc409", new Date(2004, 0, 1), new Date(2024, 0, 1)],

    ["Noodle", "Na Banda", "#eb445a", new Date(1998, 0, 1), new Date(2006, 2, 1)],
    ["Noodle", "Desaparecida", "#50c8ff", new Date(2006, 2, 1), new Date(2010, 10, 1)],
    ["Noodle", "Na Banda", "#eb445a", new Date(2010, 10, 1), new Date(2024, 0, 1)],

    ["Paula Cracker", "Guitarra (Ex)", "#d35400", new Date(1998, 0, 1), new Date(2000, 0, 1)],
    ["Del", "Rapper Fantasma", "#00e5ff", new Date(1998, 0, 1), new Date(2003, 0, 1)],
    ["Cyborg Noodle", "Substituta", "#9d9fa6", new Date(2009, 0, 1), new Date(2011, 0, 1)],
    ["Ace", "Substituto", "#7044ff", new Date(2018, 5, 1), new Date(2018, 9, 1)],
  ];

  const data = [columns, ...rows];

  const options = {
    height: 500,
    backgroundColor: '#000000',
    timeline: {rowLabelStyle: { color: '#ffffff', fontSize: 12 }, barLabelStyle: { color: '#000000', fontSize: 10 }},
    gantt: {trackHeight: 30, shadowEnabled: false}, labelStyle: { fontName: 'sans-serif', fontSize: 12 }
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Membros da banda</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent className="tab1">
        <IonHeader collapse="condense">
          <IonToolbar>
            <IonTitle size="large">Membros</IonTitle>
          </IonToolbar>
        </IonHeader>
        <IonGrid>
          <IonRow>
            <IonCol>
              <IonList>
                <IonListHeader lines='full' className="custom-header">
                    <IonLabel className="custom-header-text">Banda Real</IonLabel>
                </IonListHeader>
              </IonList>
            </IonCol>
            <IonCol size = "8">
              <IonList>
                <IonListHeader lines='full' className="custom-header-2">
                    <IonLabel className="custom-header-text">Banda virtual</IonLabel>
                </IonListHeader>
              </IonList>
            </IonCol>
          </IonRow>
          <IonRow>
            <IonCol>
              <IonAccordionGroup>
                <IonList>
                  <IonListHeader lines='full' className="custom-header">
                    <IonLabel className="custom-header-text">Membros reais</IonLabel>
                  </IonListHeader>
                </IonList>
                <IonAccordion value="first">
                  <IonItem slot="header" color="dark">
                    <IonLabel>Damon Albarn</IonLabel>
                  </IonItem>
                  <IonGrid slot="content">
                    <IonRow>
                        <IonCol className="ion-text-center">
                          <IonImg src="assets/DamonAlbarn.jpg" className="member-img" />
                        </IonCol>
                    </IonRow>
                    <IonRow>
                        <IonCol>
                            <IonList>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Nome Real:</IonLabel>
                                    <IonNote slot="end" className="member-value">Damon Albarn</IonNote>
                                </IonItem>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Também conhecido por:</IonLabel>
                                    <IonNote slot="end" className="member-value">2-D, Dan Abnormal, Norman Balda, Nomad al Arban</IonNote>
                                </IonItem>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Função</IonLabel>
                                    <IonNote slot="end" className="member-value">Vocalista, Compositor, Teclas, Guitarra</IonNote>
                                </IonItem>
                                <IonItem lines="none" className="member-detail-item">
                                    <IonLabel className="member-key">Nascimento</IonLabel>
                                    <IonNote slot="end" className="member-value">23 March 1968, Whitechapel, London, England</IonNote>
                                </IonItem>
                            </IonList>
                        </IonCol>
                    </IonRow>
                  </IonGrid>
                </IonAccordion>
                <IonAccordion value="second">
                  <IonItem slot="header" color="dark">
                    <IonLabel>Jamie Hewlett</IonLabel>
                  </IonItem>
                  <IonGrid slot="content">
                    <IonRow>
                        <IonCol className="ion-text-center">
                            <IonImg src="assets/JamieHewlett.avif" className="member-img" />
                        </IonCol>
                    </IonRow>
                    <IonRow>
                        <IonCol>
                            <IonList>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Nome Real:</IonLabel>
                                    <IonNote slot="end" className="member-value">Jamie Christopher Hewlett</IonNote>
                                </IonItem>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Também conhecido por:</IonLabel>
                                    <IonNote slot="end" className="member-value">Hewll, J. Weasel, José Hewll, J. C. Hewlett</IonNote>
                                </IonItem>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Função</IonLabel>
                                    <IonNote slot="end" className="member-value">Artista, Designer, Compositor</IonNote>
                                </IonItem>
                                <IonItem lines="none" className="member-detail-item">
                                    <IonLabel className="member-key">Nascimento</IonLabel>
                                    <IonNote slot="end" className="member-value">3 April 1968, Hawarden, Flintshire, Wales</IonNote>
                                </IonItem>
                            </IonList>
                        </IonCol>
                    </IonRow>
                  </IonGrid>
                </IonAccordion>
                <IonAccordion value="third">
                  <IonItem slot="header" color="dark">
                    <IonLabel>Mike Smith</IonLabel>
                  </IonItem>
                  <IonGrid slot="content">
                    <IonRow>
                        <IonCol className="ion-text-center">
                            <IonImg src="assets/MikeSmith.jpg" className="member-img" />
                        </IonCol>
                    </IonRow>
                    <IonRow>
                        <IonCol>
                            <IonList>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Nome Real:</IonLabel>
                                    <IonNote slot="end" className="member-value">Mike Smith</IonNote>
                                </IonItem>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Função</IonLabel>
                                    <IonNote slot="end" className="member-value">Compositor, Teclas, Sopros</IonNote>
                                </IonItem>
                                <IonItem lines="none" className="member-detail-item">
                                    <IonLabel className="member-key">Nascimento</IonLabel>
                                    <IonNote slot="end" className="member-value">1967</IonNote>
                                </IonItem>
                            </IonList>
                        </IonCol>
                    </IonRow>
                  </IonGrid>
                </IonAccordion>
                <IonAccordion value="forth">
                  <IonItem slot="header" color="dark">
                    <IonLabel>Remi Kabaka Jr.</IonLabel>
                  </IonItem>
                  <IonGrid slot="content">
                    <IonRow>
                        <IonCol className="ion-text-center">
                            <IonImg src="assets/RemiKabakaJr.jpg" className="member-img" />
                        </IonCol>
                    </IonRow>
                    <IonRow>
                        <IonCol>
                            <IonList>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Nome Real:</IonLabel>
                                    <IonNote slot="end" className="member-value">Remi Kabaka Jr.</IonNote>
                                </IonItem>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Função</IonLabel>
                                    <IonNote slot="end" className="member-value">Baterista, Percussão</IonNote>
                                </IonItem>
                                <IonItem lines="none" className="member-detail-item">
                                    <IonLabel className="member-key">Nascimento</IonLabel>
                                    <IonNote slot="end" className="member-value">11 April 1970</IonNote>
                                </IonItem>
                            </IonList>
                        </IonCol>
                    </IonRow>
                  </IonGrid>
                </IonAccordion>
              </IonAccordionGroup>
            </IonCol>
            <IonCol>
              <IonAccordionGroup>
                <IonList>
                  <IonListHeader lines='full' className="custom-header-2">
                      <IonLabel className="custom-header-text">Personagens Principais</IonLabel>
                  </IonListHeader>
                </IonList>
                <IonAccordion value="first">
                  <IonItem slot="header" color="dark">
                    <IonLabel>2-D</IonLabel>
                  </IonItem>
                  <IonGrid slot="content">
                    <IonRow>
                        <IonCol className="ion-text-center">
                            <IonImg src="assets/2-D.jpg" className="member-img" />
                        </IonCol>
                    </IonRow>
                    <IonRow>
                        <IonCol>
                            <IonList>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Nome Real</IonLabel>
                                    <IonNote slot="end" className="member-value">Stuart Harold Tusspot</IonNote>
                                </IonItem>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Também conhecido por:</IonLabel>
                                    <IonNote slot="end" className="member-value">2-D, Two-Dee, Two-Dents, Stu-Pot, Stuart D. Potato</IonNote>
                                </IonItem>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Instrumento</IonLabel>
                                    <IonNote slot="end" className="member-value">Voz, Teclado</IonNote>
                                </IonItem>
                                <IonItem lines="none" className="member-detail-item">
                                    <IonLabel className="member-key">Nascimento</IonLabel>
                                    <IonNote slot="end" className="member-value">23 May 1978, Hertfordshire, England</IonNote>
                                </IonItem>
                                <IonItem lines="none" className="member-detail-item">
                                    <IonLabel className="member-key">Voz</IonLabel>
                                    <IonNote slot="end" className="member-value">Damon Albarn (a cantar)</IonNote>
                                    <IonNote slot="end" className="member-value">Nelson De Freitas, Kevin Bishop (a falar)</IonNote>
                                </IonItem>
                            </IonList>
                        </IonCol>
                    </IonRow>
                  </IonGrid>
                </IonAccordion>
                <IonAccordion value="second">
                  <IonItem slot="header" color="dark">
                    <IonLabel>Murdoc</IonLabel>
                  </IonItem>
                  <IonGrid slot="content">
                    <IonRow>
                        <IonCol className="ion-text-center">
                            <IonImg src="assets/Murdoc.jpg" className="member-img" />
                        </IonCol>
                    </IonRow>
                    <IonRow>
                        <IonCol>
                            <IonList>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Nome Real</IonLabel>
                                    <IonNote slot="end" className="member-value">Murdoc Alphonce Niccals</IonNote>
                                </IonItem>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Também conhecido por:</IonLabel>
                                    <IonNote slot="end" className="member-value">Muds, God, MadMurdy69, Saver of Stuarts, Supreme Overlord</IonNote>
                                </IonItem>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Instrumento</IonLabel>
                                    <IonNote slot="end" className="member-value">Baixo, Guitarra, Piano, Banjo</IonNote>
                                </IonItem>
                                <IonItem lines="none" className="member-detail-item">
                                    <IonLabel className="member-key">Nascimento</IonLabel>
                                    <IonNote slot="end" className="member-value">6 June 1966, Stoke-on-Trent, Staffordshire, England</IonNote>
                                </IonItem>
                                <IonItem lines="none" className="member-detail-item">
                                    <IonLabel className="member-key">Voz</IonLabel>
                                    <IonNote slot="end" className="member-value">Phil Cornwell</IonNote>
                                </IonItem>
                            </IonList>
                        </IonCol>
                    </IonRow>
                  </IonGrid>
                </IonAccordion>
                <IonAccordion value="third">
                  <IonItem slot="header" color="dark">
                    <IonLabel>Russel</IonLabel>
                  </IonItem>
                  <IonGrid slot="content">
                    <IonRow>
                        <IonCol className="ion-text-center">
                            <IonImg src="assets/Russel.jpg" className="member-img" />
                        </IonCol>
                    </IonRow>
                    <IonRow>
                        <IonCol>
                            <IonList>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Nome Real</IonLabel>
                                    <IonNote slot="end" className="member-value">Russel Hobbs</IonNote>
                                </IonItem>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Também conhecido por:</IonLabel>
                                    <IonNote slot="end" className="member-value">Russ, Pulgasari, Rusty Hobson Jr</IonNote>
                                </IonItem>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Instrumento</IonLabel>
                                    <IonNote slot="end" className="member-value">Bateria, Ukelele, Trompete</IonNote>
                                </IonItem>
                                <IonItem lines="none" className="member-detail-item">
                                    <IonLabel className="member-key">Nascimento</IonLabel>
                                    <IonNote slot="end" className="member-value">3 June 1975, Brooklyn, New York City, United States</IonNote>
                                </IonItem>
                                <IonItem lines="none" className="member-detail-item">
                                    <IonLabel className="member-key">Voz</IonLabel>
                                    <IonNote slot="end" className="member-value">Remi Kabaka Jr.</IonNote>
                                </IonItem>
                            </IonList>
                        </IonCol>
                    </IonRow>
                  </IonGrid>
                </IonAccordion>
                <IonAccordion value="forth">
                  <IonItem slot="header" color="dark">
                    <IonLabel>ヌードル (Noodle)</IonLabel>
                  </IonItem>
                  <IonGrid slot="content">
                    <IonRow>
                        <IonCol className="ion-text-center">
                            <IonImg src="assets/Noodle.jpg" className="member-img" />
                        </IonCol>
                    </IonRow>
                    <IonRow>
                        <IonCol>
                            <IonList>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Nome Real</IonLabel>
                                    <IonNote slot="end" className="member-value">Unknown</IonNote>
                                </IonItem>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Também conhecido por:</IonLabel>
                                    <IonNote slot="end" className="member-value">Noodle, ヌードル (Nūdoru), Asian Axe Princess, Nödel</IonNote>
                                </IonItem>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Instrumento</IonLabel>
                                    <IonNote slot="end" className="member-value">Voz, Guitarra</IonNote>
                                </IonItem>
                                <IonItem lines="none" className="member-detail-item">
                                    <IonLabel className="member-key">Nascimento</IonLabel>
                                    <IonNote slot="end" className="member-value">31 October 1990, Osaka, Kansai, Japan</IonNote>
                                </IonItem>
                                <IonItem lines="none" className="member-detail-item">
                                    <IonLabel className="member-key">Voz</IonLabel>
                                    <IonNote slot="end" className="member-value">Miho Hatori, Rosie Wilson (a cantar)</IonNote>
                                    <IonNote slot="end" className="member-value">Haruka Kuroda, Haruka Abe (a falar)</IonNote>
                                </IonItem>
                            </IonList>
                        </IonCol>
                    </IonRow>
                  </IonGrid>
                </IonAccordion>
              </IonAccordionGroup>
            </IonCol>
            <IonCol>
              <IonAccordionGroup>
                <IonList>
                  <IonListHeader lines='full' className="custom-header-2">
                      <IonLabel className="custom-header-text">Personagens Secundárias</IonLabel>
                  </IonListHeader>
                </IonList>
                <IonAccordion value="first">
                  <IonItem slot="header" color="dark">
                    <IonLabel>Paula Cracker</IonLabel>
                  </IonItem>
                  <IonGrid slot="content">
                    <IonRow>
                        <IonCol className="ion-text-center">
                            <IonImg src="assets/PaulaCracker.jpg" className="member-img" />
                        </IonCol>
                    </IonRow>
                    <IonRow>
                        <IonCol>
                            <IonList>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Estatuto</IonLabel>
                                    <IonNote slot="end" className="member-value">Ex-Membro</IonNote>
                                </IonItem>
                                <IonItem lines="none" className="member-detail-item">
                                    <IonLabel className="member-key">Também conhecido por:</IonLabel>
                                    <IonNote slot="end" className="member-value">Ex-namorada do 2-D</IonNote>
                                </IonItem>
                            </IonList>
                        </IonCol>
                    </IonRow>
                  </IonGrid>
                </IonAccordion>
                <IonAccordion value="second">
                  <IonItem slot="header" color="dark">
                    <IonLabel>Del</IonLabel>
                  </IonItem>
                  <IonGrid slot="content">
                    <IonRow>
                        <IonCol className="ion-text-center">
                            <IonImg src="assets/Del.jpg" className="member-img" />
                        </IonCol>
                    </IonRow>
                    <IonRow>
                        <IonCol>
                            <IonList>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Estatuto</IonLabel>
                                    <IonNote slot="end" className="member-value">Ex-Membro (exorcizado)</IonNote>
                                </IonItem>
                                <IonItem lines="none" className="member-detail-item">
                                    <IonLabel className="member-key">Também conhecido por:</IonLabel>
                                    <IonNote slot="end" className="member-value">Del Tha Ghost Rapper</IonNote>
                                </IonItem>
                            </IonList>
                        </IonCol>
                    </IonRow>
                  </IonGrid>
                </IonAccordion>
                <IonAccordion value="third">
                  <IonItem slot="header" color="dark">
                    <IonLabel>Cyborg Noodle</IonLabel>
                  </IonItem>
                  <IonGrid slot="content">
                    <IonRow>
                        <IonCol className="ion-text-center">
                            <IonImg src="assets/Cyborg.jpg" className="member-img" />
                        </IonCol>
                    </IonRow>
                    <IonRow>
                        <IonCol>
                            <IonList>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Estatuto</IonLabel>
                                    <IonNote slot="end" className="member-value">Inativa (Destruída)</IonNote>
                                </IonItem>
                                <IonItem lines="none" className="member-detail-item">
                                    <IonLabel className="member-key">Também conhecido por:</IonLabel>
                                    <IonNote slot="end" className="member-value">Cyborg</IonNote>
                                </IonItem>
                            </IonList>
                        </IonCol>
                    </IonRow>
                  </IonGrid>
                </IonAccordion>
                <IonAccordion value="forth">
                  <IonItem slot="header" color="dark">
                    <IonLabel>Ace</IonLabel>
                  </IonItem>
                  <IonGrid slot="content">
                    <IonRow>
                        <IonCol className="ion-text-center">
                            <IonImg src="assets/Ace.jpg" className="member-img" />
                        </IonCol>
                    </IonRow>
                    <IonRow>
                        <IonCol>
                            <IonList>
                                <IonItem lines="full" className="member-detail-item">
                                    <IonLabel className="member-key">Estatuto</IonLabel>
                                    <IonNote slot="end" className="member-value">Ex-Membro</IonNote>
                                </IonItem>
                                <IonItem lines="none" className="member-detail-item">
                                    <IonLabel className="member-key">Também conhecido por:</IonLabel>
                                    <IonNote slot="end" className="member-value">Ace D. Copular</IonNote>
                                </IonItem>
                            </IonList>
                        </IonCol>
                    </IonRow>
                  </IonGrid>
                </IonAccordion>
              </IonAccordionGroup>
            </IonCol>
          </IonRow>
        </IonGrid>
        <IonCard className="chart-card">
            <IonCardHeader>
                <IonCardTitle>Linha do Tempo</IonCardTitle>
                <IonCardSubtitle>Presença dos membros na banda ao longo dos anos</IonCardSubtitle>
            </IonCardHeader>
            <IonCardContent>
                <Chart chartType="Timeline" data={data} width="100%" height="450px" options={options}/>
            </IonCardContent>
        </IonCard>
      </IonContent>
    </IonPage>
  );
};

export default Membros;
