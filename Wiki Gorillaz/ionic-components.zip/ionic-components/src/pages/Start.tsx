import { IonButton, IonCard, IonCardContent, IonCardHeader, IonCardSubtitle, IonCardTitle, IonCol, IonContent, IonGrid, IonHeader, IonImg, IonItem, IonLabel, IonList, IonListHeader, IonPage, IonRow, IonTitle, IonToolbar } from '@ionic/react';
import './Start.css';

const Menu: React.FC = () => {
  return (
    <IonPage>
      <IonContent className="menu">
        <IonImg src="/assets/gorillaz-logo.png" alt="Gorillaz Logo" className="gorillaz-logo"></IonImg>
        <IonButton shape="round" fill="clear" href="/membros" className="menu-button">
          Membros da Banda
        </IonButton>
        <IonButton shape="round" fill="clear" href="/história" className="menu-button">
          História
        </IonButton>
        <IonButton shape="round" fill="clear" href="/música" className="menu-button">
          Músicas
        </IonButton>
      </IonContent>
    </IonPage>
  );
};

export default Menu;
